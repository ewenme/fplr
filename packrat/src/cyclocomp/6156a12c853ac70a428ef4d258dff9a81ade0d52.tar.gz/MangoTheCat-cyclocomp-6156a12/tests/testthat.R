library(testthat)
library(cyclocomp)

test_check("cyclocomp")
