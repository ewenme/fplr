#' Bacon
#'
#' \figure{bacon.jpg}
#'
#' @name bacon
#' @keywords internal
#' @examples
#' magrittr::subtract(10, 1)
#'
#' library(magrittr, warn.conflicts = FALSE)
#' subtract(10, 1)
NULL
