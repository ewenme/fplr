#' Use a usethis template
#'
#' @param template Template name
#' @param save_as Name of file to create. Defaults to \code{save_as}
#' @param data A list of data passed to the template.
#' @param ignore Should the newly created file be added to \code{.Rbuildignore?}
#' @param open Should the new created file be opened in RStudio?
#' @param base_path Path to package root.
#' @keywords internal
use_template <- function(template,
                         save_as = template,
                         data = list(),
                         ignore = FALSE,
                         open = FALSE,
                         base_path = "."
                         ) {

  template_contents <- render_template(template, data)
  write_over(template_contents, file.path(base_path, save_as))

  if (ignore) {
    use_build_ignore(save_as, base_path = base_path)
  }

  if (open) {
    message("* Modify '", save_as, "'")
    open_in_rstudio(save_as, base_path = base_path)
  }

  invisible(TRUE)
}

render_template <- function(template, data = list()) {
  template_path <- find_template(template)
  paste0(whisker::whisker.render(readLines(template_path), data), "\n", collapse = "")
}

find_template <- function(template_name) {
  path <- system.file("templates", template_name, package = "usethis")
  if (identical(path, "")) {
    stop("Could not find template '", template_name, "'", call. = FALSE)
  }
  path
}

package_data <- function(base_path = ".") {
  desc <- desc::description$new(base_path)

  out <- as.list(desc$get(desc$fields()))
  if (uses_github(base_path)) {
    out$github <- gh::gh_tree_remote(base_path)
  }
  out
}

project_name <- function(base_path = ".") {
  desc_path <- file.path(base_path, "DESCRIPTION")

  if (file.exists(desc_path)) {
    desc::desc_get("Package", base_path)[[1]]
  } else {
    basename(normalizePath(base_path, mustWork = FALSE))
  }
}

use_description_field <- function(name, value, base_path = ".", overwrite = FALSE) {
  path <- file.path(base_path, "DESCRIPTION")

  curr <- desc::desc_get(name, file = path)[[1]]
  if (identical(curr, value))
    return()

  if (is.na(curr) || overwrite) {
    message("* Setting DESCRIPTION ", name, " to '", value, "'")
    desc::desc_set(name, value, file = path)
  } else {
    message("* Preserving existing field ", name)
  }
}

use_dependency <- function(package, type, base_path = ".") {
  stopifnot(is.character(package), length(package) == 1)
  stopifnot(is.character(type), length(type) == 1)

  if (!requireNamespace(package, quietly = TRUE)) {
    stop(package, " must be installed before you can take a dependency on it",
      call. = FALSE)
  }

  types <- c("Imports", "Depends", "Suggests", "Enhances", "LinkingTo")
  names(types) <- tolower(types)
  type <- types[[match.arg(tolower(type), names(types))]]

  deps <- desc::desc_get_deps(base_path)
  has_dep <- any(deps$package == package & deps$type == type)
  if (!has_dep) {
    message("* Adding ", package, " to ", type, ".")
    desc::desc_set_dep(package, type, file = file.path(base_path, "DESCRIPTION"))
  }

  invisible()
}

use_directory <- function(path,
                          ignore = FALSE,
                          base_path = ".") {

  if (!file.exists(base_path)) {
    stop("'", base_path, "' does not exist", call. = FALSE)
  }
  pkg_path <- file.path(base_path, path)

  if (file.exists(pkg_path)) {
    if (!is_dir(pkg_path)) {
      stop("'", path, "' exists but is not a directory.", call. = FALSE)
    }
  } else {
    message("* Creating '", pkg_path, "/'")
    ok <- dir.create(pkg_path, showWarnings = FALSE, recursive = TRUE)

    if (!ok) {
      stop("Failed to create path", call. = FALSE)
    }
  }

  if (ignore) {
    use_build_ignore(path, base_path = base_path)
  }

  invisible(TRUE)
}

open_in_rstudio <- function(path, base_path = ".") {
  path <- file.path(base_path, path)

  if (!rstudioapi::isAvailable())
    return()

  if (!rstudioapi::hasFun("navigateToFile"))
    return()

  rstudioapi::navigateToFile(path)
}
