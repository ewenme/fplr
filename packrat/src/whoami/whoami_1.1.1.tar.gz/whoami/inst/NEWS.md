
# 1.1.0

* Fallbacks, instead of errors, #2


# 1.0.0

First release
