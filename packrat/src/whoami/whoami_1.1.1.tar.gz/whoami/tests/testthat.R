library(testthat)
library(whoami)

test_check("whoami")
