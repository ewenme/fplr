
#' @import igraph
NULL

#' Random function
#' @export

func1 <- function() {

}
