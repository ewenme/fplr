
context("library() ok")

test_that("library is ok here", {
  library("stats")
  expect_true(TRUE)
})
