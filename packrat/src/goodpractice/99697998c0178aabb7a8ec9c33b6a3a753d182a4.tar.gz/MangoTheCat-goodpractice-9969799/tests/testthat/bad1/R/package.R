
#' @import igraph
#' @importFrom desc desc_get
NULL
