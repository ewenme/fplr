
th2 <- function() {
  T + T + F * F
}
