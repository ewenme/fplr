
semicolons <- function() {

  print("why would you add?");
  print("a semicolon here?");

  "this is one"; "at the middle"; "so not that bad"

  "trailing semicolon and whitespace";   
}
