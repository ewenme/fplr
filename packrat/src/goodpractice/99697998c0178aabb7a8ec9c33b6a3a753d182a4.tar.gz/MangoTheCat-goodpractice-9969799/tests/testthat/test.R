
context("goodpractice")

test_that("goodpractice works", {

  expect_true(TRUE)

})
