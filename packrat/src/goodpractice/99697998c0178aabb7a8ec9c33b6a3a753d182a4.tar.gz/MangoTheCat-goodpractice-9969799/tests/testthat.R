library(testthat)
library(goodpractice)

test_check("goodpractice")
